A brief description of what this project does and who it's for

### Project Title: Implementing a Fully-Connected Neural Network for BRDF Dataset Regression

### Project Description:
This project involves the development of a fully-connected neural network from scratch using Python and NumPy. The neural network is designed to perform regression tasks on the Bidirectional Reflectance Distribution Function (BRDF) dataset. It is a four-layer network comprising an input layer, two hidden layers, and an output layer.

The neural network predicts the intensity values of red, green, and blue (RGB) light based on given input features from the dataset. Each layer of the network uses ReLU (Rectified Linear Unit) as the activation function, except for the output layer, which uses a linear activation function suitable for regression.

The training process incorporates features like shuffling of training data at each epoch to promote stochastic learning and early stopping to prevent overfitting. The dataset is split into training, validation, and testing sets, ensuring that half of the data is used for training, with the rest split between validation and testing.

### How to Use the Project:
1. **Data Preparation**: Obtain the BRDF dataset and save it in a text format. The dataset should have features in the first columns and the RGB values in the last three columns.

2. **Network Initialization**: Set the size of the input features, the number of neurons in the two hidden layers, and the number of output neurons (3 for RGB). Initialize the neural network with these parameters.

3. **Training the Network**: Train the neural network using the training dataset. You can adjust the `learning_rate` and `epochs` based on the performance observed during training.

4. **Evaluation**: After training, use the validation set to fine-tune hyperparameters if necessary. Evaluate the final model on the test set to determine its performance.

5. **Plotting Errors**: The training and validation errors are plotted against epochs to visualize the learning process and convergence of the model.

6. **Saving and Loading Weights**: The final weights of the model are saved to text files. These can be loaded later to perform predictions without retraining.

7. **Prediction**: Use the trained model to predict RGB values for new input features by passing them through the forward propagation function of the network.

### Steps to Run the Project:
1. Load your dataset by replacing `'output1.txt'` with the path to your dataset file in the `load_dataset` function call in Python Program.

2. Customize `input_size`, `hidden_size1`, `hidden_size2`, and `learning_rate` as needed for your specific dataset.

3. Run the entire script to train the neural network. Monitor the output for early stopping notifications and overall training and validation error trends.

4. Once training is complete, the error plots will be displayed, showing the training and validation error at each epoch.

5. Check the final test cost printed after testing the network to evaluate its performance.

6. If necessary, adjust the neural network architecture or hyperparameters based on the test cost and error plots, and retrain.

#EXTRA CREDIT 
# Try different activation functions
activation_functions = ['relu', 'sigmoid', 'tanh', 'leaky_relu']

# Initialize the dictionary to store validation errors for each activation function
validation_results = {}

for activation in activation_functions:
    print(f"Training with {activation} activation")
    nn = NeuralNetwork(input_size, hidden_size1, hidden_size2, output_size, activation)
    _, validation_errors = nn.train(X_train, Y_train, X_val, Y_val, epochs=1000, learning_rate=0.26)
    validation_results[activation] = validation_errors
    print(f"Completed training with {activation}")

# Compare and report the results
for activation, errors in validation_results.items():
    final_validation_error = errors[-1]
    print(f"Final validation error with {activation}: {final_validation_error}")

# 7. Plot Training and Validation Errors
plt.figure(figsize=(10, 6))
plt.plot(training_errors, label='Training Error', color='red')
plt.plot(validation_errors, label='Validation Error', color='blue')
plt.xlabel('Epochs')
plt.ylabel('Error')
plt.legend()
plt.show()

To run it is the same as above

By following these steps and utilizing the provided code, you can apply the neural network to your BRDF dataset to predict RGB reflectance values. The script is designed to be self-contained and requires only NumPy and Matplotlib libraries for execution.

## Authors

- Ratnesh Pawar
- Rohan Sonawane
- Abhishek Dhale
- Thivstan Vishal James
- Neil Duraiswami