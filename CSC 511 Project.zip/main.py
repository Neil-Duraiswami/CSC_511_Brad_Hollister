# 1. Importing the Libraries
import numpy as np
import matplotlib.pyplot as plt

# 2. Defining the Neural Network Class
class NeuralNetwork:
    def __init__(self, input_size, hidden_size1, hidden_size2, output_size, activation='relu'):
        # Initialize weights and biases for four layers
        self.W1 = np.random.randn(input_size, hidden_size1) * 0.01
        self.b1 = np.zeros((1, hidden_size1))
        self.W2 = np.random.randn(hidden_size1, hidden_size2) * 0.01
        self.b2 = np.zeros((1, hidden_size2))
        self.W3 = np.random.randn(hidden_size2, hidden_size2) * 0.01
        self.b3 = np.zeros((1, hidden_size2))
        self.W4 = np.random.randn(hidden_size2, output_size) * 0.01
        self.b4 = np.zeros((1, output_size))
        self.activation = activation

    # Activation Functions
    def relu(self, Z):
        return np.maximum(0, Z)

    def relu_derivative(self, Z):
        return Z > 0

    def sigmoid(self, Z):
        return 1 / (1 + np.exp(-Z))

    def sigmoid_derivative(self, Z):
        s = self.sigmoid(Z)
        return s * (1 - s)

    def tanh(self, Z):
        return np.tanh(Z)

    def tanh_derivative(self, Z):
        return 1 - np.tanh(Z) ** 2

    def leaky_relu(self, Z, alpha=0.01):
        return np.where(Z > 0, Z, alpha * Z)

    def leaky_relu_derivative(self, Z, alpha=0.01):
        return np.where(Z > 0, 1, alpha)

    # Forward Propagation
    def forward(self, X):
        self.Z1 = np.dot(X, self.W1) + self.b1
        self.A1 = self.activate(self.Z1)
        self.Z2 = np.dot(self.A1, self.W2) + self.b2
        self.A2 = self.activate(self.Z2)
        self.Z3 = np.dot(self.A2, self.W3) + self.b3
        self.A3 = self.activate(self.Z3)
        self.Z4 = np.dot(self.A3, self.W4) + self.b4
        output = self.Z4
        return output

    # Activation Wrapper
    def activate(self, Z):
        if self.activation == 'sigmoid':
            return self.sigmoid(Z)
        elif self.activation == 'tanh':
            return self.tanh(Z)
        elif self.activation == 'leaky_relu':
            return self.leaky_relu(Z)
        else:
            return self.relu(Z)

    # Compute Cost
    def compute_cost(self, output, Y):
        cost = np.mean(np.square(output - Y))
        return cost

    # Backward Propagation
    def backward(self, X, Y, output, learning_rate):
        m = Y.shape[0]

        # Gradient of the cost with respect to the output
        dZ4 = output - Y
        dW4 = (1 / m) * np.dot(self.A3.T, dZ4)
        db4 = (1 / m) * np.sum(dZ4, axis=0, keepdims=True)

        # Backpropagation through third hidden layer
        dA3 = np.dot(dZ4, self.W4.T)
        dZ3 = np.multiply(dA3, self.activate_derivative(self.Z3))
        dW3 = (1 / m) * np.dot(self.A2.T, dZ3)
        db3 = (1 / m) * np.sum(dZ3, axis=0, keepdims=True)

        # Backpropagation through second hidden layer
        dA2 = np.dot(dZ3, self.W3.T)
        dZ2 = np.multiply(dA2, self.activate_derivative(self.Z2))
        dW2 = (1 / m) * np.dot(self.A1.T, dZ2)
        db2 = (1 / m) * np.sum(dZ2, axis=0, keepdims=True)

        # Backpropagation through first hidden layer
        dA1 = np.dot(dZ2, self.W2.T)
        dZ1 = np.multiply(dA1, self.activate_derivative(self.Z1))
        dW1 = (1 / m) * np.dot(X.T, dZ1)
        db1 = (1 / m) * np.sum(dZ1, axis=0, keepdims=True)

        # Update weights and biases
        self.W4 -= learning_rate * dW4
        self.b4 -= learning_rate * db4
        self.W3 -= learning_rate * dW3
        self.b3 -= learning_rate * db3
        self.W2 -= learning_rate * dW2
        self.b2 -= learning_rate * db2
        self.W1 -= learning_rate * dW1
        self.b1 -= learning_rate * db1

    # Activation Derivative Wrapper
    def activate_derivative(self, Z):
        if self.activation == 'sigmoid':
            return self.sigmoid_derivative(Z)
        elif self.activation == 'tanh':
            return self.tanh_derivative(Z)
        elif self.activation == 'leaky_relu':
            return self.leaky_relu_derivative(Z)
        else:
            return self.relu_derivative(Z)

    # Training Function
    def train(self, X_train, Y_train, X_val, Y_val, epochs, learning_rate):
        # Initialize early stopping variables
        best_val_cost = float('inf')
        patience = 10
        patience_counter = 0

        # Training loop
        training_errors = []
        validation_errors = []

        for epoch in range(epochs):
            # Shuffle the training data
            permutation = np.random.permutation(X_train.shape[0])
            X_train_shuffled = X_train[permutation]
            Y_train_shuffled = Y_train[permutation]

            output = self.forward(X_train_shuffled)
            cost = self.compute_cost(output, Y_train_shuffled)
            self.backward(X_train_shuffled, Y_train_shuffled, output, learning_rate)

            training_errors.append(cost)

            # Validation error
            val_output = self.forward(X_val)
            val_cost = self.compute_cost(val_output, Y_val)
            validation_errors.append(val_cost)

            # Early stopping
            if val_cost < best_val_cost:
                best_val_cost = val_cost
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter > patience:
                    print(f"Stopping early at epoch {epoch}")
                    break

            if epoch % 100 == 0:
                print(f"Epoch {epoch}, Training Cost: {cost}, Validation Cost: {val_cost}")

        return training_errors, validation_errors


# 3. Dataset Loading and Splitting Functions
def load_dataset(file_name):
    data = np.loadtxt(file_name, delimiter=' ')
    np.random.shuffle(data)  # Shuffle the dataset
    X = data[:, :4]  # First 4 columns as features
    Y = data[:, 4:]  # Last 3 columns as labels (r, g, b)
    return X, Y


# 3. Modify the split_dataset function to use half of the data for training
def split_dataset(X, Y, train_ratio=0.5, val_ratio=0.25):
    total_samples = X.shape[0]
    train_size = int(total_samples * train_ratio)
    val_size = int(total_samples * val_ratio)

    # Shuffle the dataset before splitting
    permutation = np.random.permutation(total_samples)
    X_shuffled = X[permutation]
    Y_shuffled = Y[permutation]

    X_train = X_shuffled[:train_size]
    Y_train = Y_shuffled[:train_size]

    X_val = X_shuffled[train_size:train_size + val_size]
    Y_val = Y_shuffled[train_size:train_size + val_size]

    X_test = X_shuffled[train_size + val_size:]
    Y_test = Y_shuffled[train_size + val_size:]

    return X_train, Y_train, X_val, Y_val, X_test, Y_test


# 4. Load and Preprocess the Dataset
X, Y = load_dataset('output1.txt')
X_train, Y_train, X_val, Y_val, X_test, Y_test = split_dataset(X, Y)

# 5. Initialize the Neural Network
input_size = 4
hidden_size1 = 10  # Example size, you can adjust as needed
hidden_size2 = 8   # The number of neurons in the second hidden layer
output_size = 3
nn = NeuralNetwork(input_size, hidden_size1, hidden_size2, output_size)

# Example: Setting the learning rate
learning_rate = 1.8

# 6. Train the Neural Network
training_errors, validation_errors = nn.train(X_train, Y_train, X_val, Y_val, epochs=1000, learning_rate=learning_rate)

# Try different activation functions
activation_functions = ['relu', 'sigmoid', 'tanh', 'leaky_relu']

# Initialize the dictionary to store validation errors for each activation function
validation_results = {}

for activation in activation_functions:
    print(f"Training with {activation} activation")
    nn = NeuralNetwork(input_size, hidden_size1, hidden_size2, output_size, activation)
    _, validation_errors = nn.train(X_train, Y_train, X_val, Y_val, epochs=1000, learning_rate=0.26)
    validation_results[activation] = validation_errors
    print(f"Completed training with {activation}")

# Compare and report the results
for activation, errors in validation_results.items():
    final_validation_error = errors[-1]
    print(f"Final validation error with {activation}: {final_validation_error}")

# 7. Plot Training and Validation Errors
plt.figure(figsize=(10, 6))
plt.plot(training_errors, label='Training Error', color='red')
plt.plot(validation_errors, label='Validation Error', color='blue')
plt.xlabel('Epochs')
plt.ylabel('Error')
plt.legend()
plt.show()

# 8. Save the Final Weights to a File
np.savetxt('weights_layer1.txt', nn.W1)
np.savetxt('weights_layer2.txt', nn.W2)
np.savetxt('weights_layer3.txt', nn.W3)

# 9. Test the Network
test_output = nn.forward(X_test)
test_cost = nn.compute_cost(test_output, Y_test)
print(f"Test Cost: {test_cost}")
